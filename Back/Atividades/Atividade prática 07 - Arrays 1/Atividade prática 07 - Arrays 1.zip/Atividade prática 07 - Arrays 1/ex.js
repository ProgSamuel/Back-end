var vetor1 = [1, 2, 3]
var vetor2 = ["quatro", "cinco", "seis"]

console.log(vetor1)
console.log(vetor2)

var vetor3 = vetor1.concat(vetor2)

console.log(vetor1)
console.log(vetor3)

/* 
 --------- Caso queira concatenar mais de um array -------

 var vetor3 = vetor1.concat(vetor2, vetor)

*/