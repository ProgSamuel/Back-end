/* 1. Crie um objeto em JavaScript para colocar dois atributos de um
produto. Atribua o preço e descrição do produto com o valor “90” e a
descrição com o valor “Mouse”. Mostre no console o valor dos dois
atributos. */

let item = {
    valor : 90,
    Produto : "Mouse"
}

console.log(item);